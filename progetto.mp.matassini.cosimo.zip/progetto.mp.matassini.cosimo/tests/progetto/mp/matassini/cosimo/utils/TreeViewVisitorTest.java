package progetto.mp.matassini.cosimo.utils;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

import progetto.mp.matassini.cosimo.application.Page;
import progetto.mp.matassini.cosimo.application.PageGroup;

public class TreeViewVisitorTest {
	
	@Test
	public void testViewStructureOfSinglePage() {
		Page page = new Page("title");
		TreeViewVisitor visitor = new TreeViewVisitor(
			new PageTypeDecorator(
				new PageTitleInfo()
			)
		);
		page.accept(visitor);
		assertThat(visitor.viewStructure()).isEqualTo("Page -> title\n");
	}
	
	@Test
	public void testViewStructureOfEmptyPageGroup() {
		PageGroup group = new PageGroup("title");
		TreeViewVisitor visitor = new TreeViewVisitor(
			new PageTypeDecorator(
				new PageTitleInfo()
			)
		);
		group.accept(visitor);
		assertThat(visitor.viewStructure()).isEqualTo("PageGroup -> title\n");
	}
	
	@Test
	public void testViewStructureForMultiplePages() {
		PageGroup group = new PageGroup("groupTitle");
		PageGroup subGroup = new PageGroup("subGroupTitle");
		PageGroup subGroup2 = new PageGroup("subGroup2Title");
		Page page1 = new Page("page1Title");
		Page page2 = new Page("page2Title");
		Page page3 = new Page("page3Title");
		subGroup.addPage(subGroup2);
		subGroup.addPage(page3);
		group.addPage(page1);
		group.addPage(subGroup);
		group.addPage(page2);
		TreeViewVisitor visitor = new TreeViewVisitor(
			new PageTypeDecorator(
				new PageTitleInfo()
			)
		);
		group.accept(visitor);
		assertThat(visitor.viewStructure()).isEqualTo(
			"PageGroup -> groupTitle\n" + 
			"	Page -> page1Title\n" +
			"	PageGroup -> subGroupTitle\n" + 
			"		PageGroup -> subGroup2Title\n" +
			"		Page -> page3Title\n" + 
			"	Page -> page2Title\n"
		);
	}
}
