package progetto.mp.matassini.cosimo.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

import org.junit.Test;

import progetto.mp.matassini.cosimo.application.PageGroup;
import progetto.mp.matassini.cosimo.application.Page;

public class PagTitleInfoTest {
	
	@Test
	public void testNullPageThrowsException() {
		assertThatNullPointerException()
			.isThrownBy(() -> new PageTitleInfo().getResult(null));
	}

	@Test
	public void testGetResultForPage() {
		Page page = new Page("titleOfPage");
		PageTitleInfo pti = new PageTitleInfo();
		assertThat(pti.getResult(page)).isEqualTo("titleOfPage");
	}
	
	@Test
	public void testGetResultForPageGroup() {
		PageGroup pageGroup = new PageGroup("titleOfPageGroup");
		PageTitleInfo pti = new PageTitleInfo();
		assertThat(pti.getResult(pageGroup)).isEqualTo("titleOfPageGroup");
	}
}
