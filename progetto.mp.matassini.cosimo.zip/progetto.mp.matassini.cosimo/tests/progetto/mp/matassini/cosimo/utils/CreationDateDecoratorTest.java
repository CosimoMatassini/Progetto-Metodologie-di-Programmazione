package progetto.mp.matassini.cosimo.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

import org.junit.Test;

import progetto.mp.matassini.cosimo.application.Page;
import progetto.mp.matassini.cosimo.application.PageGroup;

public class CreationDateDecoratorTest {
	
	@Test
	public void testNullComponentIsNotAssigned() {
		assertThatNullPointerException()
			.isThrownBy(() -> new CreationDateDecorator(null));
	}
	
	@Test
	public void testGetResult() {
		IPageInfo decorator = new CreationDateDecorator(new PageTitleInfo());
		Page page = new Page("TitleOfPage");
		String result = decorator.getResult(page);
		assertThat(result)
			.isEqualTo("TitleOfPage, created on " + page.getCreationDate());
	}
	
	@Test
	public void testDecoratorWorksMultipleTimesWithPage() {
		IPageInfo decorator = new CreationDateDecorator(
			new CreationDateDecorator(
				new PageTitleInfo()
			)
		);
		Page page = new Page("TitleOfPage");
		assertThat(decorator.getResult(page))
			.isEqualTo("TitleOfPage, created on "
				+ page.getCreationDate()
				+ ", created on "
				+ page.getCreationDate()
			);
	}
	
	@Test
	public void testDecoratorWorksMultipleTimesWithPageGroup() {
		IPageInfo decorator = new CreationDateDecorator(
			new CreationDateDecorator(
				new PageTitleInfo()
			)
		);
		PageGroup pageGroup = new PageGroup("TitleOfPageGroup");
		assertThat(decorator.getResult(pageGroup))
			.isEqualTo("TitleOfPageGroup, created on "
				+ pageGroup.getCreationDate() 
				+ ", created on "
				+ pageGroup.getCreationDate()
			);
	}
}
