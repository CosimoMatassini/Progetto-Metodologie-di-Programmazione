package progetto.mp.matassini.cosimo.utils;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

import progetto.mp.matassini.cosimo.application.Page;
import progetto.mp.matassini.cosimo.application.PageGroup;

public class AbstractPageDecoratorTest {

	@Test
	public void testTypeAndDateDecoratorForPage() {
		IPageInfo decorator = new CreationDateDecorator(
			new PageTypeDecorator(
				new PageTitleInfo()
			)
		);
		Page page = new Page("TitleOfPage");
		assertThat(decorator.getResult(page))
			.isEqualTo("Page -> TitleOfPage, created on " 
				+ page.getCreationDate()
			);
	}
	
	@Test
	public void testTypeAndDateDecoratorForPageGroup() {
		IPageInfo decorator = new CreationDateDecorator(
			new PageTypeDecorator(
				new PageTitleInfo()
			)
		);
		PageGroup pageGroup = new PageGroup("TitleOfPageGroup");
		assertThat(decorator.getResult(pageGroup))
			.isEqualTo("PageGroup -> TitleOfPageGroup, created on "
				+ pageGroup.getCreationDate()
			);
	}
}
