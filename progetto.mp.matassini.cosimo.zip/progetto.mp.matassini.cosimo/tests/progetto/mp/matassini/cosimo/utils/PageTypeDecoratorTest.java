package progetto.mp.matassini.cosimo.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

import org.junit.Test;

import progetto.mp.matassini.cosimo.application.Page;
import progetto.mp.matassini.cosimo.application.PageGroup;

public class PageTypeDecoratorTest {

	@Test
	public void testNullComponentIsNotAssigned() {
		assertThatNullPointerException()
			.isThrownBy(() -> new PageTypeDecorator(null));
	}
	
	@Test
	public void testGetResultForPage() {
		IPageInfo decorator = new PageTypeDecorator(new PageTitleInfo());
		Page page = new Page("TitleOfPage");
		assertThat(decorator.getResult(page))
			.isEqualTo("Page -> TitleOfPage");
	}
	
	@Test
	public void testGetResultForPageGroup() {
		IPageInfo decorator = new PageTypeDecorator(new PageTitleInfo());
		PageGroup group = new PageGroup("TitleOfPageGroup");
		assertThat(decorator.getResult(group))
			.isEqualTo("PageGroup -> TitleOfPageGroup");
	}
	
	@Test
	public void testDecoratorWorksMultipleTimesWithPage() {
		IPageInfo decorator = new PageTypeDecorator(
			new PageTypeDecorator(
				new PageTitleInfo()
			)
		);
		Page page = new Page("TitleOfPage");
		assertThat(decorator.getResult(page))
			.isEqualTo("Page -> Page -> TitleOfPage");
	}
	
	@Test
	public void testDecoratorWorksMultipleTimesWithPageGroup() {
		IPageInfo decorator = new PageTypeDecorator(
			new PageTypeDecorator(
				new PageTitleInfo()
			)
		);
		PageGroup pageGroup = new PageGroup("TitleOfPageGroup");
		assertThat(decorator.getResult(pageGroup))
			.isEqualTo("PageGroup -> PageGroup -> TitleOfPageGroup");
	}
	
	@Test
	public void testOperationIsNotRecursive() {
		IPageInfo decorator = new PageTypeDecorator(new PageTitleInfo());
		PageGroup group = new PageGroup("TitleOfPageGroup");
		Page page = new Page("TitleOfPage");
		group.addPage(page);
		assertThat(decorator.getResult(group))
			.isEqualTo("PageGroup -> TitleOfPageGroup");
	}
}
