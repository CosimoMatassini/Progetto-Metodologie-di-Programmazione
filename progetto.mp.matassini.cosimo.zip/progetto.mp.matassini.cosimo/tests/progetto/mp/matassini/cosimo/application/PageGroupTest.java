package progetto.mp.matassini.cosimo.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class PageGroupTest {
	
	private PageGroup group;
	private PageGroup subGroup;
	private Page page1;
	private Page page2;
	
	@Before
	public void setUp() {
		group = new PageGroup("Title of the page group");
		subGroup = new PageGroup("Title of the subPageGroup");
		page1 = new Page("A Page with a title");
		page1.setText(new StringBuilder("Lorem ipsum dolor sit amet."));
		page2 = new Page("A Page with another title");
		page2.setText(new StringBuilder("L. ipsum is some random text. This is random text."));
	}
	
	@Test
	public void testNullThrowsException() {
		assertThatNullPointerException()
			.isThrownBy(() -> new Page(null));
	}

	@Test
	public void testOnePageOccurrenceIsFound() {
		subGroup.getNestedPages().add(page2);
		group.getNestedPages().add(page1);
		group.getNestedPages().add(subGroup);
		Map<Page, List<Integer>> found = group.find("random");
		assertThat(found).hasSize(1);
		assertThat(found).containsKeys(page2);
		assertThat(found).containsValues(List.of(17, 38));
	}
	
	@Test
	public void testMultiplePagesOccurrencesAreFound() {
		subGroup.getNestedPages().add(page2);
		group.getNestedPages().add(page1);
		group.getNestedPages().add(subGroup);
		Map<Page, List<Integer>> found = group.find("ipsum");
		assertThat(found).hasSize(2);
		assertThat(found).containsKeys(page1, page2);
		assertThat(found).containsValues(List.of(6), List.of(3));
	}
	
	@Test
	public void testNoOccurrenceIsFound() {
		subGroup.getNestedPages().add(page2);
		group.getNestedPages().add(page1);
		group.getNestedPages().add(subGroup);
		Map<Page, List<Integer>> found = group.find("foo");
		assertThat(found).isEmpty();
	}
	
	@Test
	public void testPageisAdded() {
		group.addPage(page1);
		assertThat(group.getNestedPages())
			.contains(page1);
	}
	
	@Test
	public void testPageGroupisAdded() {
		group.addPage(subGroup);
		assertThat(group.getNestedPages())
			.contains(subGroup);
	}
	
	@Test
	public void testNullIsNotAddedToNestedPages() {
		assertThatNullPointerException()
			.isThrownBy(() -> group.addPage(null));
	}
	
	@Test
	public void testPageIsRemoved() {
		group.getNestedPages().add(page1);
		group.removePage(page1);
		assertThat(group.getNestedPages()).doesNotContain(page1);
	}
	
	@Test
	public void testPageGroupIsRemoved() {
		subGroup.getNestedPages().add(page2);
		group.getNestedPages().add(subGroup);
		group.getNestedPages().add(page1);
		group.removePage(subGroup);
		assertThat(group.getNestedPages()).doesNotContain(subGroup);
		assertThat(group.getNestedPages()).doesNotContain(page2);
	}
	
	@Test
	public void testNoPageIsRemoved() {
		assertThat(group.removePage(page2)).isFalse();
	}
	
	@Test
	public void testPageGroupIterator() {
	group.getNestedPages().add(page1);
	group.getNestedPages().add(subGroup);
	subGroup.getNestedPages().add(page2);
	assertThat(group.iterator())
		.toIterable()
		.containsExactlyInAnyOrder(page1, subGroup);
	}
}
