package progetto.mp.matassini.cosimo.application;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.*;

import java.util.List;
import java.util.Map;

public class PageTest {
	
	private Page page;
	
	@Before
	public void setUp() {
		page = new Page("PageTitle");
	}
	
	@Test
	public void testNullTitleIsNotSet() {
		assertThatNullPointerException()
			.isThrownBy(() -> new Page(null));
	}
	
	@Test
	public void testTextAsStringIsAdded() {
		page.addText("Lorem ipsum");
		assertThat(page.getText().toString())
			.isEqualTo("Lorem ipsum");
		page.addText(" dolor sit amet.");
		assertThat(page.getText().toString())
			.isEqualTo("Lorem ipsum dolor sit amet.");
	}
	
	@Test
	public void testTextAsStringBuilderIsAdded() {
		StringBuilder textToAddAtTheBeginning = new StringBuilder("Lorem ipsum");
		page.addText(textToAddAtTheBeginning);
		assertThat(page.getText().toString())
			.isEqualTo("Lorem ipsum");
		StringBuilder textToAddAtTheEnd = new StringBuilder(" dolor sit amet.");
		page.addText(textToAddAtTheEnd);
		assertThat(page.getText().toString())
			.isEqualTo("Lorem ipsum dolor sit amet.");
	}
	
	@Test
	public void testNullAsStringIsNotAdded() {
		String textToAdd = null;
		assertThatNullPointerException()
			.isThrownBy(() -> page.addText(textToAdd));
	}
	
	@Test
	public void testNullAsStringBuilderIsNotAdded() {
		StringBuilder textToAdd = null;
		assertThatNullPointerException()
			.isThrownBy(() -> page.addText(textToAdd));
	}
	
	@Test
	public void testOneOccurrenceIsFound() {
		page.setText(new StringBuilder("Lorem ipsum dolor sit amet."));
		Map<Page, List<Integer>> found = page.find("ipsum");
		assertThat(found).hasSize(1);
		assertThat(found).containsKeys(page);
		assertThat(found).containsValues(List.of(6));
	}
	
	@Test
	public void testMultipleOccurrencesAreFound() {
		page.setText(new StringBuilder("Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet."));
		Map<Page, List<Integer>> found = page.find("Lorem");
		assertThat(found).hasSize(1);
		assertThat(found).containsKeys(page);
		assertThat(found).containsValues(List.of(0, 28));
	}
	
	@Test
	public void testNoOccurrenceIsFound() {
		page.setText(new StringBuilder("Lorem ipsum dolor sit amet."));
		Map<Page, List<Integer>> found = page.find("foo");
		assertThat(found).isEmpty();
	}
}
