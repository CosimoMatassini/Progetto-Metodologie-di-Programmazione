package progetto.mp.matassini.cosimo.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

import org.junit.Before;
import org.junit.Test;

public class PageFinderVisitorTest {
	
	private PageGroup group;
	private PageGroup group2;
	private PageGroup subGroup;
	private PageGroup subGroup2;
	private Page page1;
	private Page page2;
	private Page page3;
	private Page page4;
	private Page page5;
	
	@Before
	public void setUp() {
		group = new PageGroup("titleofaGrOuP");
		group2 = new PageGroup("titleofanothergroup");
		subGroup = new PageGroup("TITLEOFAGROUP");
		subGroup2 = new PageGroup("This is the title");
		page1 = new Page("this is a page");
		page2 = new Page("This Is A Page");
		page3 = new Page("THIS IS A PAGE");
		page4 = new Page("this is another page");
		page5 = new Page("This IS THE Title");
		subGroup.getNestedPages().add(page5);
		subGroup.getNestedPages().add(subGroup2);
		group2.getNestedPages().add(page3);
		group2.getNestedPages().add(page4);
		group.getNestedPages().add(subGroup);
		group.getNestedPages().add(page1);
		group.getNestedPages().add(page2);
		group.getNestedPages().add(group2);
	}

	@Test
	public void testNullStringIsNotAssigned() {
		assertThatNullPointerException()
			.isThrownBy(() -> new PageFinderVisitor(null));
	}

	@Test
	public void testPageIsFound() {
		PageFinderVisitor visitor = new PageFinderVisitor("This Is ANOTHER PAGe");
		group.accept(visitor);
		assertThat(visitor.getPages())
			.containsExactlyInAnyOrder(page4);
	}
	
	@Test
	public void testPageGroupIsFound() {
		PageFinderVisitor visitor = new PageFinderVisitor("TITLEofAnoThergroup");
		group.accept(visitor);
		assertThat(visitor.getPages())
			.containsExactlyInAnyOrder(group2);
		
	}
	
	@Test
	public void testMultiplePagesAreFound() {
		PageFinderVisitor visitor = new PageFinderVisitor("This IS A PAge");
		group.accept(visitor);
		assertThat(visitor.getPages())
			.containsExactlyInAnyOrder(page1, page2, page3);
	}
	
	@Test
	public void testMultiplePageGroupsAreFound() {
		PageFinderVisitor visitor = new PageFinderVisitor("TitleOfAGroup");
		group.accept(visitor);
		assertThat(visitor.getPages())
			.containsExactlyInAnyOrder(group, subGroup);
	}
	
	@Test
	public void testPagesAndPageGroupsAreFound() {
		PageFinderVisitor visitor = new PageFinderVisitor("THIS IS THE TITLe");
		group.accept(visitor);
		assertThat(visitor.getPages())
			.containsExactlyInAnyOrder(page5, subGroup2);
	}
	
	@Test
	public void testNoPageIsFound() {
		PageFinderVisitor visitor = new PageFinderVisitor("title");
		group.accept(visitor);
		assertThat(visitor.getPages()).isEmpty();
	}
	
	@Test
	public void testPagesIterator() {
	PageFinderVisitor visitor = new PageFinderVisitor("nothing");
	visitor.getPages().add(group);
	visitor.getPages().add(subGroup);
	visitor.getPages().add(page1);
	visitor.getPages().add(page2);
	assertThat(visitor.iterator())
		.toIterable()
		.containsExactlyInAnyOrder(subGroup, page1, page2, group);
	}
}
