package progetto.mp.matassini.cosimo.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

import org.junit.Before;
import org.junit.Test;

public class ReplaceAllVisitorTest {
	
	private PageGroup group;
	private PageGroup subGroup;
	private Page page1;
	private Page page2;
	
	@Before
	public void setUp() {
		group = new PageGroup("Title of the page group");
		subGroup = new PageGroup("Title of the subPageGroup");
		page1 = new Page("A Page with a title");
		page1.setText(new StringBuilder("Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet."));
		page2 = new Page("A Page with another title");
		page2.setText(new StringBuilder("L. ipsum is some random text. This is random text."));
		subGroup.addPage(page2);
		group.addPage(page1);
		group.addPage(subGroup);
	}
	
	@Test
	public void testNullOldTextIsNotAssigned() {
		assertThatNullPointerException()
			.isThrownBy(() -> new ReplaceAllVisitor(null, "new text"));
	}
	
	@Test
	public void testNullNewTextIsNotAssigned() {
		assertThatNullPointerException()
			.isThrownBy(() -> new ReplaceAllVisitor("old text", null));
	}

	@Test
	public void testTextIsReplacedInOnePage() {
		IPageVisitor visitor = new ReplaceAllVisitor("dolor sit amet", "is a string");
		group.accept(visitor);
		assertThat(page1.getTitle())
			.isEqualTo("A Page with a title");
		assertThat(page1.getText().toString())
			.isEqualTo("Lorem ipsum is a string. Lorem ipsum is a string.");
		assertThat(page2.getTitle())
			.isEqualTo("A Page with another title");
		assertThat(page2.getText().toString())
			.isEqualTo("L. ipsum is some random text. This is random text.");
	}
	
	@Test
	public void testTextIsReplacedInMultiplePages() {
		IPageVisitor visitor = new ReplaceAllVisitor("L", "R");
		group.accept(visitor);
		assertThat(page1.getTitle())
			.isEqualTo("A Page with a title");
		assertThat(page1.getText().toString())
			.isEqualTo("Rorem ipsum dolor sit amet. Rorem ipsum dolor sit amet.");
		assertThat(page2.getTitle())
			.isEqualTo("A Page with another title");
		assertThat(page2.getText().toString())
			.isEqualTo("R. ipsum is some random text. This is random text.");
	}
	
	@Test
	public void testTextIsRemoved() {
		IPageVisitor visitor = new ReplaceAllVisitor("ipsum ", "");
		group.accept(visitor);
		assertThat(page1.getTitle())
			.isEqualTo("A Page with a title");
		assertThat(page1.getText().toString())
			.isEqualTo("Lorem dolor sit amet. Lorem dolor sit amet.");
		assertThat(page2.getTitle())
			.isEqualTo("A Page with another title");
		assertThat(page2.getText().toString())
			.isEqualTo("L. is some random text. This is random text.");
	}
	
	@Test
	public void testNoTextIsRemoved() {
		IPageVisitor visitor = new ReplaceAllVisitor("foo", "hello");
		group.accept(visitor);
		assertThat(page1.getTitle())
			.isEqualTo("A Page with a title");
		assertThat(page1.getText().toString())
			.isEqualTo("Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet.");
		assertThat(page2.getTitle())
			.isEqualTo("A Page with another title");
		assertThat(page2.getText().toString())
			.isEqualTo("L. ipsum is some random text. This is random text.");
	}
}
