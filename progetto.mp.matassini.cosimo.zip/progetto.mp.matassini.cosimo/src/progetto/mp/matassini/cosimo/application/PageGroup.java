package progetto.mp.matassini.cosimo.application;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class PageGroup extends AbstractPage {
	
	private Collection<AbstractPage> nestedPages;

	public PageGroup(String title) {
		super(title);
		nestedPages = new ArrayList<>();
	}

	@Override
	public Map<Page, List<Integer>> find(String text) {
		return nestedPages.stream()
			.flatMap(page -> page.find(text).entrySet().stream()) 
			.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	}
	
	public boolean addPage(AbstractPage page) {
		Objects.requireNonNull(page, "Cannot add null as page.");
		return nestedPages.add(page);
	}
	
	public boolean removePage(AbstractPage page) {
		return nestedPages.remove(page);
	}
	
	public Iterator<AbstractPage> iterator() {
		return nestedPages.iterator();
	}

	@Override
	public void accept(IPageVisitor visitor) {
		visitor.visitPageGroup(this);
	}

	Collection<AbstractPage> getNestedPages() {
		return nestedPages;
	}
}
