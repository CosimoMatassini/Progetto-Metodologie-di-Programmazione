package progetto.mp.matassini.cosimo.application;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;

public class PageFinderVisitor implements IPageVisitor {

	private String titleToMatch;
	private Collection<AbstractPage> pages;

	public PageFinderVisitor(String titleToMatch) {
		this.titleToMatch = Objects.requireNonNull(titleToMatch);
		pages = new HashSet<>();
	}
	

	private void match(AbstractPage page) {
		if(titleToMatch.equalsIgnoreCase(page.getTitle())) {
			pages.add(page);
		}
	}

	@Override
	public void visitPage(Page page) {
		match(page);
	}

	@Override
	public void visitPageGroup(PageGroup pageGroup) {
		match(pageGroup);
		pageGroup.iterator()
			.forEachRemaining(page -> page.accept(this));
	}

	public Iterator<AbstractPage> iterator() {
		return pages.iterator();
	}

	Collection<AbstractPage> getPages() {
		return pages;
	}
}