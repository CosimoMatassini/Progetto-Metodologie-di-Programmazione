package progetto.mp.matassini.cosimo.application;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Page extends AbstractPage {
	
	private StringBuilder text;

	public Page(String title) {
		super(title);
		text = new StringBuilder();
	}

	public StringBuilder getText() {
		return text;
	}

	public void addText(String text) {
		Objects.requireNonNull(text, "Text cannot be null");
		this.text.append(text);
	}
	
	public void addText(StringBuilder text) {
		Objects.requireNonNull(text, "Text cannot be null");
		this.text.append(text);
	}
	
	@Override
	public Map<Page, List<Integer>> find(String text) {
		return IntStream.range(0, this.text.length() - text.length() + 1)
			.filter(i -> this.text.substring(i, i + text.length()).equals(text))
			.boxed()
			.collect(Collectors.groupingBy(i -> this));
	}

	@Override
	public void accept(IPageVisitor visitor) {
		visitor.visitPage(this);
	}
	
	void setText(StringBuilder text) {
		this.text = text;
	}
}