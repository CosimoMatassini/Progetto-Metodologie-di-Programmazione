package progetto.mp.matassini.cosimo.application;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public abstract class AbstractPage {

	private String title;
	private LocalDate creationDate;

	public abstract Map<Page, List<Integer>> find(String text);

	protected AbstractPage(String title) {
		this.title = Objects.requireNonNull(title, "Cannot create a page with null title.");
		creationDate = LocalDate.now();
	}

	public String getTitle() {
		return title;
	}
	
	public LocalDate getCreationDate() {
		return creationDate;
	}
	
	public abstract void accept(IPageVisitor visitor);
}