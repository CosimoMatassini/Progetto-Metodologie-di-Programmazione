package progetto.mp.matassini.cosimo.application;

public interface IPageVisitor {
	
	void visitPage(Page page);
	
	void visitPageGroup(PageGroup pageGroup);
	
}