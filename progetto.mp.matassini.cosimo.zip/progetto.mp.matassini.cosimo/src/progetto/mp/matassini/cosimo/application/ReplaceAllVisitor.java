package progetto.mp.matassini.cosimo.application;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ReplaceAllVisitor implements IPageVisitor {

	private String oldText;
	private String newText;
	
	public ReplaceAllVisitor(String oldText, String newText) {
		this.oldText = Objects.requireNonNull(oldText);
		this.newText = Objects.requireNonNull(newText);
	}
	
	@Override
	public void visitPage(Page page) {
		Map<Page, List<Integer>> result = page.find(oldText);
		result.forEach((key, values) -> {
			Collections.reverse(values);
			values.stream()
				.forEach(value -> 
				 	page.getText()
				 		.replace(value, value + oldText.length(), newText)
				);
		});
	}

	@Override
	public void visitPageGroup(PageGroup pageGroup) {
		pageGroup.iterator()
			.forEachRemaining(page -> page.accept(this));
	}
}