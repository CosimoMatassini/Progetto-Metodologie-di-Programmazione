package progetto.mp.matassini.cosimo.utils;

import progetto.mp.matassini.cosimo.application.AbstractPage;

public interface IPageInfo {
	
	String getResult(AbstractPage page);
	
}