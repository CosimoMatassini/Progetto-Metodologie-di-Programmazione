package progetto.mp.matassini.cosimo.utils;

import java.util.Objects;
import progetto.mp.matassini.cosimo.application.AbstractPage;

public class PageTitleInfo implements IPageInfo {

	@Override
	public String getResult(AbstractPage page) {
		Objects.requireNonNull(page);
		return page.getTitle();
	}
}