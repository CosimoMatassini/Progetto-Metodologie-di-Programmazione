package progetto.mp.matassini.cosimo.utils;

import progetto.mp.matassini.cosimo.application.AbstractPage;
import progetto.mp.matassini.cosimo.application.IPageVisitor;
import progetto.mp.matassini.cosimo.application.Page;
import progetto.mp.matassini.cosimo.application.PageGroup;

public class PageTypeDecorator extends AbstractPageDecorator {

	public PageTypeDecorator(IPageInfo component) {
		super(component);
	}

	@Override
	public String getResult(AbstractPage page) {
		StringBuilder result = new StringBuilder("");
		page.accept(new IPageVisitor() {
			
			@Override
			public void visitPage(Page page) {
				result.append("Page -> ");
			}

			@Override
			public void visitPageGroup(PageGroup pageGroup) {
				result.append("PageGroup -> ");
			}
		});
		return result.toString() + super.getResult(page);
	}
}