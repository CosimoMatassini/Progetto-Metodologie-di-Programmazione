package progetto.mp.matassini.cosimo.utils;

import progetto.mp.matassini.cosimo.application.AbstractPage;
import progetto.mp.matassini.cosimo.application.IPageVisitor;
import progetto.mp.matassini.cosimo.application.Page;
import progetto.mp.matassini.cosimo.application.PageGroup;

public class TreeViewVisitor implements IPageVisitor {
	
	private StringBuilder view;
	private IPageInfo element;
	private int depthLevel;
	
	public TreeViewVisitor(IPageInfo element) {
		this.element = element;
		view = new StringBuilder("");
		depthLevel = 0;
	}
	
	private void appendString(AbstractPage page) {
		view.append("\t".repeat(depthLevel) + element.getResult(page) + "\n");
	}

	@Override
	public void visitPage(Page page) {
		appendString(page);
	}

	@Override
	public void visitPageGroup(PageGroup pageGroup) {
		appendString(pageGroup);
		depthLevel++;
		pageGroup.iterator()
			.forEachRemaining(p -> p.accept(this));
		depthLevel--;
	}
	
	public String viewStructure() {
		return view.toString();
	}
}
