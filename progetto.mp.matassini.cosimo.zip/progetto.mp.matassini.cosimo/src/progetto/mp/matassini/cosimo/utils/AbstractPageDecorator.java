package progetto.mp.matassini.cosimo.utils;

import java.util.Objects;

import progetto.mp.matassini.cosimo.application.AbstractPage;

public abstract class AbstractPageDecorator implements IPageInfo {

	private IPageInfo component;

	protected AbstractPageDecorator(IPageInfo component) {
		this.component = Objects.requireNonNull(component);
	}

	public String getResult(AbstractPage page) {
		return component.getResult(page);
	}
}