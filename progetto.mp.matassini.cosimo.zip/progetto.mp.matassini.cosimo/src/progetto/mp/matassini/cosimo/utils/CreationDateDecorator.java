package progetto.mp.matassini.cosimo.utils;

import progetto.mp.matassini.cosimo.application.AbstractPage;

public class CreationDateDecorator extends AbstractPageDecorator{
	
	public CreationDateDecorator(IPageInfo component) {
		super(component);
	}

	@Override
	public String getResult(AbstractPage page) {
		return super.getResult(page)
			+ ", created on " 
			+ page.getCreationDate();
	}
}